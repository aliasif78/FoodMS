module finalProject {
	requires javafx.base;
	requires javafx.graphics;
	requires javafx.fxml;
	requires javafx.controls;
	requires java.sql;
	
	opens application to javafx.fxml;
	exports application to javafx.graphics;
	opens BusinessLogic to javafx.fxml, javafx.base;
	opens DB to javafx.fxml;
}