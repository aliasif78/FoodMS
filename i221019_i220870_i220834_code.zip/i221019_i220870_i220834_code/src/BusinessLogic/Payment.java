package BusinessLogic;

public class Payment {

}
