package BusinessLogic;

public class CashOnDelivery {

}
