package BusinessLogic;

public class RestaurantFeedback {

}
