package BusinessLogic;

public class CardPayment {

}
