package BusinessLogic;

public class RiderFeedback {

}
