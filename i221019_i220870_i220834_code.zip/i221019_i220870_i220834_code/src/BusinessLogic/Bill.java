package BusinessLogic;

public class Bill {

}
