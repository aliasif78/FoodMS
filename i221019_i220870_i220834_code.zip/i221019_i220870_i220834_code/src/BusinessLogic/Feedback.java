package BusinessLogic;

public class Feedback {

}
