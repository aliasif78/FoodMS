package BusinessLogic;

import java.util.ArrayList;

public class testMain {
	
	public class accountCount {
	    public static int count = 6;
	}
	public class restaurantCount {
	    public static int count = 3;
	}
	public class riderCount {
	    public static int count = 2;
	}
	public class customerCount {
	    public static int count = 2;
	}
	public class menuCount {
	    public static int count = 3;
	}
	public class cartCount {
	    public static int count = 2;
	}
	
	public static void main(String[] args)
	{
		/*
		Account adminAcc = new Account(accountCount.count, "20-11-22", "abdSaq", "abd123");
		accountCount.count++;
		ArrayList<Customer> customerList = new ArrayList<>();
		ArrayList<Rider> riderList = new ArrayList<>();
		ArrayList<Restaurant> restaurantList = new ArrayList<>();
		
		Admin adminObj = new Admin("Abdullah", "03215162770", "jhash", adminAcc, 25262, customerList, riderList, restaurantList);
		
		for (int i = 0 ; i < 5; i++)
			adminObj.restSignUp();
		
		for (int i = 0 ; i < 5; i++)
			adminObj.riderSignUp();
		
		
		adminObj.selectRestaurant();
		adminObj.authorizeRestaurant(1);

		adminObj.selectRider();
		adminObj.authorizeRider(1);*/
		
	}

}
